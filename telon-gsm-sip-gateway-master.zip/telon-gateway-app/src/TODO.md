dongle
call limit 1 -> react-native-sip2
IncomingCancel - параметр.
Incoming - в список CDR, логировать

MTK, snapdragon - для прозвона на занятость, сброс при дозвоне.

Вылет при 2 звонке


Группировка шлюзов в 1 устройство - есть готовые решения? Групповой набор менеджер
FOP2 аналог

Переподключение к SIP при вылете

При вылете библиотеке. (SIGFAULT) - перезапуск библиотеки


При повторном hangup - ошибка



https://www.avito.ru/sankt-peterburg/telefony/smartfon_xiaomi_mi_4c_1922238906 1100 4c
https://www.avito.ru/sankt-peterburg/telefony/telefon_xiaomi_mi4c_1909406172 1200 4c
https://www.avito.ru/sankt-peterburg/telefony/xiaomi_redmi_note_5a_1917939490 1300 note 5a без touch ветеранов
https://www.avito.ru/sankt-peterburg/telefony/xiaomi_note_2_1948981761?slocation=107621 note2 1500 трещина на экране
https://www.avito.ru/sankt-peterburg/telefony/xiaomi_redmi_4x_ksiaomi_1920063468?slocation=107621 4x 1550 техноложка экран бит (показывает, тач - хз)
https://www.avito.ru/sankt-peterburg/telefony/telefon_xiaomi_1949617273 - redmi 6a только эмблема mi
https://www.avito.ru/sankt-peterburg/telefony/redmi_4a_razbit_ekran_1864602815?slocation=107621 redmi 4a - 1800 битый экран
https://www.avito.ru/murino/telefony/xiaomi_redmi_4x_1937533738?slocation=107621 1900 4x трещины
https://www.avito.ru/sankt-peterburg/telefony/telefon_xiaomi_1932405262?slocation=107621 2000 redmi 5a фонит динамик, экран целый? - узнать?

https://www.avito.ru/sankt-peterburg/telefony/redmi_6_a_1931876292?slocation=107621 redmi6a - сколы, 2000 торг (обмен не дешевле 1800)


aaudio.h playback incall:
06-08 19:33:57.546   455  7420 E         : Request requires android.permission.MODIFY_PHONE_STATE

get lineageos sources