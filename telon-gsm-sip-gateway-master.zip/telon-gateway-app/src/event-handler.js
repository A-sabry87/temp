module.exports = async (store, data) => {
    console.log("event-handlers.js",store.data);
    //if(data.type == '...') {
    //    store.dispatch(...);
    //}
};
