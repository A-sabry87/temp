git add .
git pull
git commit -a -m "auto"
git push
#npm version patch
#npm publish
#./npm_publish.sh