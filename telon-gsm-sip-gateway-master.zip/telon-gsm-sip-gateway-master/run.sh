#./git_update.sh

#watchman watch-del-all
#rm -rf node_modules
#yarn install
#yarn start --reset-cache
#rm -rf /tmp/metro-*

#yarn add https://github.com/telefon-one/react-native-tele https://github.com/telefon-one/react-native-sip2
yarn android