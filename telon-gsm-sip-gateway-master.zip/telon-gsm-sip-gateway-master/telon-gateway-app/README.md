# gateway

**UPDATE**: Now is compatible with RN 0.60+ (AndroidX)


## Support

 - Android
 
## To do

 - [ ] Add ToDo

## Examples

- [Google.Play] TODO

## Installation

## Usage

## API

